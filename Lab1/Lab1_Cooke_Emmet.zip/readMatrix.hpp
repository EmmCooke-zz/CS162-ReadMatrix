/*************************************************************
* Author: Emmet Cooke
* Date: 9/24/2017
*************************************************************/
#ifndef READ_MATRIX_HPP
#define READ_MATRIX_HPP

void readMatrix(int**, int);

#endif