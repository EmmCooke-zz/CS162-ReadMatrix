#ifndef VALIDATE_INPUT_HPP
#define VALIDATE_INPUT_HPP

#include <string>
using std::string;

bool checkStringToInt(string);

#endif

