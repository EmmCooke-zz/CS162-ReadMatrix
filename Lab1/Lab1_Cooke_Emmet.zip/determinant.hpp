/*************************************************************
* Author: Emmet Cooke
* Date: 9/24/2017
*************************************************************/
#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

int determinant(int**, int);

#endif